# src/automated_security_helper

This directory contains the Python package code for the automated_security_helper package.

This package provides some Python-based functions for ASH and is intended to be the project
location for any new Python development for ASH.

This package uses Poetry to manage dependencies and packaging. To read more about Poetry,
please see the [Poetry documentation](https://python-poetry.org/docs/).
